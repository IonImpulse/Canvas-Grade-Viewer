function gradeCheck() {
    function checkZeroConvert(stringNum) {
        if (parseFloat(stringNum) == NaN) {
            stringNum = 0.0;
            //console.log("Did not work");
        } else {
            stringNum = parseFloat(stringNum);
        }
        return stringNum;
    
    }

    function findIGrade(inputAssignment) {
        var outputGrade = inputAssignment[inputAssignment.length - 56].replace(/\s/g,'');
        //console.log("First",outputGrade);

        if (isNaN(inputAssignment[inputAssignment.length - 54].replace(/\s/g,'')) == false) {
            outputGrade = inputAssignment[inputAssignment.length - 60].replace(/\s/g,'');
            //console.log("Reverted whatif", outputGrade)
        } else {
            if (outputGrade != "" && isNaN(parseFloat(outputGrade)) == true) {
                outputGrade = isolateWeight(inputAssignment[inputAssignment.length - 43].replace(/\s/g,''));
                //console.log("Second",outputGrade);
            }
        }
        
        

        outputGrade = parseFloat(outputGrade);
        return(outputGrade);
    }

    function isolateWeight(weightString) {
        weightString = weightString.slice(weightString.indexOf(">") + 1, weightString.indexOf("<", weightString.indexOf(">")));
        return weightString;
    }

    var assignmentsList = document.getElementsByClassName("student_assignment editable");
    //console.log(assignmentsList);
    var grades = [];
    var gradeMaxes = [];
    var gradeTypes = [];
    var weightSum = 100;

    for (var i = 0; i < assignmentsList.length; i++) {
        var tempAssignment = assignmentsList[i].innerHTML.split("\n");
        var lengthInner = tempAssignment.length;
        //console.log(tempAssignment);

        var gradeFound = findIGrade(tempAssignment);

        if (gradeFound != "" && isNaN(gradeFound) == false && checkZeroConvert(tempAssignment[lengthInner-31].replace(/\s/g,'')) != 0) {
            
            grades.push(gradeFound);

            gradeMaxes.push(checkZeroConvert(tempAssignment[lengthInner-31].replace(/\s/g,'')));

            gradeTypes.push(isolateWeight(tempAssignment[4]));
        }
    }

    //console.log(grades);
    //console.log(gradeMaxes);

    var weightsListRaw = document.getElementById("assignments-not-weighted").innerHTML.split("\n");
    console.log(weightsListRaw);
    if (isolateWeight(weightsListRaw[3]) == "Assignments are weighted by group:") {
        var weightsExist = true;
        console.log("True")
        var weightNames = [];
        var weightValues = [];
        var iterations = weightsListRaw.length - 15;

        for (i = 14; i < iterations; i = i + 4) {
            var tempWeightName = weightsListRaw[i];
            var tempWeightValue = weightsListRaw[i + 1];

            weightNames.push(isolateWeight(tempWeightName));
            weightValues.push(parseFloat(isolateWeight(tempWeightValue)));
        }

    } else {
        var weightsExist = false;
    }

    if (weightsExist == false) {
        var totalGrade = 0;
        var totalMax = 0;
        for (var i = 0; i < grades.length; i++) {
            totalGrade = totalGrade + grades[i];
            totalMax = totalMax + gradeMaxes[i];
        }

        if (totalGrade == 0) {
            totalGrade = "N/A";
        } else {
            totalGrade = totalGrade/totalMax*100;
        }


    } else {
        var totalGrade = 0;
        var all_group_grades = [];
        var all_group_maxes = [];

        for (var i = 0; i < weightNames.length; i++) {
            all_group_grades.push(0);
            all_group_maxes.push(0);

            for (var j = 0; j < grades.length; j++) {
                if (gradeTypes[j] == weightNames[i]) {
                    all_group_grades[i] = all_group_grades[i] + grades[j];
                    all_group_maxes[i] = all_group_maxes[i] + gradeMaxes[j];
                }
            }
        }

        //console.log(weightValues);
        var emptyWeights = [];
        weightSum = 0;

        for (var i = 0; i < weightValues.length; i++) {
            weightSum = weightSum + weightValues[i];
        }


        for (var i = 0; i < all_group_maxes.length; i++) {
            if (all_group_maxes[i] == 0) {
                emptyWeights.push(weightValues[i]);
                var multiplier = weightValues[i];
                for (var j = 0; j < weightValues.length; j++) {
                    weightValues[j] = weightValues[j] * (weightSum/(weightSum-multiplier));
                }
            }
        }

        for (var i = 0; i < all_group_maxes.length; i++) {
          if (all_group_maxes[i] != 0) {
              //console.log(totalGrade, weightGrade[i], weightMax[i], weightValues[i]);
              totalGrade = totalGrade + (all_group_grades[i]/all_group_maxes[i] * (weightValues[i]/100) * 100);
          }
        }
    }
    
    console.log(all_group_grades)
    console.log(all_group_maxes)
    console.log(weightNames)
    
    console.log(totalGrade);

    // Put the now-known grades in the HTML
    var gradeOutput = document.getElementById("student-grades-right-content");
    var tempDiv = gradeOutput.innerHTML.split("\n");
    tempDiv[2] = "Total: ";

    if (weightSum != 100) {
      tempDiv[2] = tempDiv[2] + ((totalGrade/weightSum*100).toString()).slice(0,5) + "% ("  + (totalGrade.toString()).slice(0,5) + "% out of " + (weightSum.toString()).slice(0,5) + "%)";
    }
    else {
      tempDiv[2] = tempDiv[2] + (totalGrade.toString()).slice(0,5) + "%";
    }
    document.getElementById("student-grades-right-content").innerHTML = tempDiv.join("\n");

    if (weightsExist) {
        group_grade_sections = document.getElementsByClassName("student_assignment hard_coded group_total");
        
        for (var i = 0; i < group_grade_sections.length; i++) {
            var section = group_grade_sections[i].innerHTML.split("\n");
            
            grade_to_insert = (100*all_group_grades[i]/all_group_maxes[i]).toString().slice(0,5);
            
            string_to_insert = `${all_group_grades[i]}/${all_group_maxes[i]} (${grade_to_insert}%)`;
            
            section[18] = " ";
            section[19] = " ";
            section[20] = " ";

            section[22] = string_to_insert;

            console.log(section)
            group_grade_sections[i].innerHTML = section.join("\n");
            
        }

    }
}

document.addEventListener('DOMContentLoaded', function() {   
    gradeCheck();
}, false);

document.addEventListener('mouseup', function() {
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
     }
    async function WaitForGrade() {
        //console.log("waiting..");
        await sleep(200);
        //console.log("done!");
        gradeCheck();
        //console.log("mouse clicked");
        
    }
    WaitForGrade();
}, false);

document.addEventListener('keydown', function(e) {
    if(e.keyCode == 13) {
        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
         }
        async function WaitForGrade() {
            //console.log("waiting..");
            await sleep(200);
            //console.log("done!");
            gradeCheck();
            //console.log("mouse clicked");
            
        }
        WaitForGrade();
        //console.log("enter was pressed");
    }
}, false);