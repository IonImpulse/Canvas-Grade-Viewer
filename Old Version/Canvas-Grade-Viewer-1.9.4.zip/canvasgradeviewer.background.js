// Set survey link on uninstallation:

if(chrome.runtime.setUninstallURL) {
    chrome.runtime.setUninstallURL('https://forms.gle/Ypc1WXU14aoqNwHF6');
}